import gc
import json
import os
from pathlib import Path
import time
from medical_posttrain.evidence import sha256,write_json
from medical_posttrain.training.lora import MemoryMonitor

def run(ev):
    # Forking a process with initialized CUDA is not supported by vLLM.
    os.environ['VLLM_WORKER_MULTIPROC_METHOD']='spawn'
    from vllm import LLM,SamplingParams
    from vllm.lora.request import LoRARequest
    from transformers import AutoTokenizer
    tok=AutoTokenizer.from_pretrained(ev.config['model'],local_files_only=True)
    args=dict(model=ev.config['model'],tokenizer=ev.config['model'],dtype='bfloat16',tensor_parallel_size=1,
              max_model_len=4096,max_num_seqs=16,gpu_memory_utilization=.65,enable_lora=True,max_lora_rank=32,
              enable_sleep_mode=True,enforce_eager=True,seed=ev.config['seed'],enable_prefix_caching=False)
    write_json(ev.path/'vllm_args.json',args)
    t=time.monotonic()
    with MemoryMonitor() as mm:
        llm=LLM(**args)
        cold=time.monotonic()-t
        if ev.config['purpose']=='length':
            return length(ev,llm,tok,SamplingParams,mm,cold)
        if not ev.config['adapter']: raise ValueError('vLLM identity requires explicit trained adapter')
        adapter=Path(ev.config['adapter'])
        ah=sha256(adapter/'adapter_model.safetensors')
        request=LoRARequest('stage0_adapter_'+ah[:12],1,str(adapter))
        prompt=tok.apply_chat_template([{'role':'user','content':'请选择 C，并用 <answer>C</answer> 表示最终答案。'}],tokenize=False,add_generation_prompt=True,enable_thinking=True)
        assert prompt.endswith('<|im_start|>assistant\n')
        params=SamplingParams(temperature=0,max_tokens=32,logprobs=5,prompt_logprobs=5)
        outputs={}; elapsed={}
        for name,req in [('base',None),('adapter',request),('base_negative',None)]:
            t=time.monotonic(); result=llm.generate([prompt],params,lora_request=req,use_tqdm=False)[0]; elapsed[name]=time.monotonic()-t
            outputs[name]=serialize(result)
        assert outputs['base']['token_ids']==outputs['base_negative']['token_ids']
        # Same prompt token logprobs provide a matched-token positive control even if generation text agrees.
        deltas=[]
        for a,b in zip(outputs['base']['prompt_logprobs'][1:],outputs['adapter']['prompt_logprobs'][1:]):
            for key in a.keys()&b.keys(): deltas.append(abs(a[key]-b[key]))
        assert deltas and max(deltas)>1e-5,'Adapter produced no measurable logprob change'
        write_json(ev.path/'identity_outputs.json',outputs)
        ev.metric(event='vllm_identity',cold_load_seconds=cold,adapter_sha256=ah,max_matched_prompt_logprob_delta=max(deltas),seconds=elapsed,output_tokens_per_second={k:len(v['token_ids'])/elapsed[k] for k,v in outputs.items()},**mm.result())
        t=time.monotonic(); llm.sleep(level=1); sleep=time.monotonic()-t
        sleep_mem=mm.nv.nvmlDeviceGetMemoryInfo(mm.handle).used
        # Sleeping rollout allows an actual BF16 LoRA actor to use the same GPU.
        import subprocess,sys
        switch_config=dict(purpose='lora',model=ev.config['model'],adapter=str(adapter))
        # A dedicated subprocess runs one backward; no full SFT launcher or formal stage is entered.
        argv=[sys.executable,'-m','medical_posttrain.verification.switch_actor',str(ev.path)]
        t=time.monotonic()
        p=subprocess.run(argv,stdout=open(ev.path/'switch_actor.stdout.log','w'),stderr=open(ev.path/'switch_actor.stderr.log','w'),timeout=600)
        assert p.returncode==0,'Actor switch subprocess failed; see switch_actor.stderr.log'
        switch=time.monotonic()-t
        t=time.monotonic(); llm.wake_up(); wake=time.monotonic()-t
        after=serialize(llm.generate([prompt],params,lora_request=request,use_tqdm=False)[0])
        assert after['token_ids']==outputs['adapter']['token_ids'],'sleep/wake changed adapter identity'
        write_json(ev.path/'after_wake.json',after)
        ev.metric(event='sleep_wake_switch',sleep_seconds=sleep,wake_seconds=wake,sleep_memory_bytes=sleep_mem,actor_process_seconds=switch,**mm.result())
    return dict(gates={'vllm_load':True,'vllm_lora_identity':True,'actor_rollout_switch':True},cold_load_seconds=cold,adapter_sha256=ah,sleep_seconds=sleep,wake_seconds=wake,max_prompt_logprob_delta=max(deltas))

def serialize(r):
    o=r.outputs[0]
    def logs(rows):
        return [None if row is None else {str(k):v.logprob for k,v in row.items()} for row in rows] if rows else None
    return dict(text=o.text,token_ids=list(o.token_ids),finish_reason=o.finish_reason,logprobs=logs(o.logprobs),prompt_logprobs=logs(r.prompt_logprobs))

def length(ev,llm,tok,SamplingParams,mm,cold):
    from medical_posttrain.data.format import parse_answer
    data=json.loads(Path('experiments/stage0/bootstrap/cmexam-train32.json').read_text())
    prompts=[tok.apply_chat_template([{'role':'user','content':row['Question']+'\n'+row['Options']+'\n请推理，并将最终选项字母写在 <answer>...</answer> 内。'}],tokenize=False,add_generation_prompt=True,enable_thinking=True) for row in data['rows']]
    assert len(prompts)==32
    result=[]
    for limit in (512,1024):
        params=SamplingParams(n=4,temperature=.6,top_p=1.,top_k=-1,max_tokens=limit,seed=ev.config['seed'])
        t=time.monotonic(); outputs=llm.generate(prompts,params,use_tqdm=False); seconds=time.monotonic()-t
        rows=[]
        for i,r in enumerate(outputs):
            for j,o in enumerate(r.outputs):
                parsed=parse_answer(o.text)
                row=dict(prompt_id=f'cmexam_train_row_{i}',group_member=j,response=o.text,token_ids=list(o.token_ids),answer=data['rows'][i]['Answer'],parsed=parsed,closed='<answer>' in o.text and '</answer>' in o.text,format_valid=parsed is not None,correct=parsed==data['rows'][i]['Answer'],truncated=o.finish_reason=='length',finish_reason=o.finish_reason)
                rows.append(row)
        assert len(rows)==128
        write_json(ev.bulk/f'outputs_{limit}.json',rows); ev.artifact(ev.bulk/f'outputs_{limit}.json','train_only_length_responses')
        metrics=dict(limit=limit,prompts=32,responses=128,closure_rate=sum(x['closed'] for x in rows)/128,truncation_rate=sum(x['truncated'] for x in rows)/128,format_validity=sum(x['format_valid'] for x in rows)/128,accuracy=sum(x['correct'] for x in rows)/128,generated_tokens=sum(len(x['token_ids']) for x in rows),average_output_tokens=sum(len(x['token_ids']) for x in rows)/128,seconds=seconds)
        metrics['output_tokens_per_second']=metrics['generated_tokens']/seconds
        result.append(ev.metric(event='output_length',**metrics,**mm.result()))
        for row in sorted(rows,key=lambda x:len(x['token_ids']),reverse=True)[:2]:
            ev.case(f'length_{limit}',f"limit={limit}; truncation={row['truncated']}; parsed={row['parsed']}",category='BAD_CASE' if row['truncated'] else 'BOUNDARY_CASE',response=row)
    return dict(gates={'response_length':True},conditions=result,cold_load_seconds=cold,proposal_1024=result[0]['closure_rate']<.95 or result[0]['truncation_rate']>.05)
